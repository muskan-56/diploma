// script.js

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', () => {
    // Change header image based on screen size
    function updateImage() {
        let img = document.getElementById("header-image");
        if (img) {  // Check if element exists
            if (window.innerWidth <= 768) {
                img.src = "assets/heading-mobile.png";
            } else {
                img.src = "assets/heading-big-screen.png";
            }
        }
    }

    window.addEventListener("resize", updateImage);
    updateImage(); // Initial call

    // Mobile Navbar Toggle
    const mobileMenu = document.getElementById("mobile-menu");
    const navLinks = document.querySelector(".nav-links");

    if (mobileMenu && navLinks) {  // Check if elements exist
        mobileMenu.addEventListener("click", () => {
            navLinks.classList.toggle("active");
        });
    }

    // Sidebar Content Switching
    const sidebarLinks = document.querySelectorAll(".sidebar-links a");
    const contents = document.querySelectorAll(".content");

    if (sidebarLinks.length > 0 && contents.length > 0) {  // Check if elements exist
        sidebarLinks.forEach(link => {
            link.addEventListener("click", (e) => {
                // Let PHP handle navigation, only manage active states if needed
                // Remove active class from all sidebar links
                sidebarLinks.forEach(l => l.classList.remove("active"));
                // Add active class to clicked link
                link.classList.add("active");

                // Hide all content sections
                contents.forEach(content => content.classList.remove("active"));
                // Show the selected content
                const section = link.getAttribute("data-section");
                const targetContent = document.getElementById(section);
                if (targetContent) {
                    targetContent.classList.add("active");
                }
            });
        });
    }

    // Course Details Toggle
    const courseTitles = document.querySelectorAll(".course-title");

    if (courseTitles.length > 0) {  // Check if elements exist
        courseTitles.forEach(title => {
            title.addEventListener("click", () => {
                const details = title.nextElementSibling; // Get the .course-details div
                if (details) {
                    details.classList.toggle("active");

                    // Optional: Close other open details (accordion style)
                    courseTitles.forEach(otherTitle => {
                        if (otherTitle !== title) {
                            const otherDetails = otherTitle.nextElementSibling;
                            if (otherDetails) {
                                otherDetails.classList.remove("active");
                            }
                        }
                    });
                }
            });
        });
    }
});