<!-- social-media.php -->
<div class="social-media-bar">
    <a href="https://www.facebook.com/adit.cvmuniversity" target="_blank" class="social-icon">
        <img src="images/facebook.png" alt="Facebook">
    </a>
    <a href="https://twitter.com/adit_cvmu" target="_blank" class="social-icon">
        <img src="images/twitter.png" alt="Twitter">
    </a>
    <a href="https://www.instagram.com/adit_cvmuniversity/" target="_blank" class="social-icon">
        <img src="images/instagram.jpeg" alt="Instagram">
    </a>
    <a href="https://www.linkedin.com/school/adit_cvmuniversity" target="_blank" class="social-icon">
        <img src="images/linkedin.png" alt="LinkedIn">
    </a>
</div>

<style>
    .social-media-bar {
        position: fixed;
        right: 20px;
        top: 50%;
        transform: translateY(-50%);
        display: flex;
        flex-direction: column;
        gap: 15px;
        z-index: 1000;
    }

    .social-icon {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #333;
        border-radius: 50%;
        transition: all 0.3s ease;
        text-decoration: none;
    }

    .social-icon:hover {
        background-color: #555;
        transform: scale(1.1);
    }

    .social-icon img {
        width: 20px;
        height: 20px;
    }
</style>
