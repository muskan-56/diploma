<?php
// No redirect; just set a default section
$section = isset($_GET['section']) ? $_GET['section'] : 'vision';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diploma Programs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="dept.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
            text-align: center;
        }
        .table-container {
            margin: 20px auto;
            width: 90%;
            max-width: 800px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 12px;
            text-align: left;
        }
        th {
            background: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background: #f2f2f2;
        }
        tr:hover {
            background: #ddd;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <?php include 'navbar.php'; ?>
    <div class="table-container">
        <h2>Diploma Programs</h2>
        <table>
            <tr>
                <th>Programmes</th>
                <th>Year of Inception</th>
                <th>Approved Intake</th>
            </tr>
            <tr>
                <td>Diploma in Automobile Engineering</td>
                <td>2023-2024</td>
                <td>30</td>
            </tr>
            <tr>
                <td>Diploma in Computer Engineering</td>
                <td>2024-2025</td>
                <td>30</td>
            </tr>
            <tr>
                <td>Diploma in Electrical Engineering (Industrial Control)</td>
                <td>2025-2026</td>
                <td>30</td>
            </tr>
            <tr>
                <td>Diploma in Electronics Engineering (Consumer Electronics)</td>
                <td>2024-2025</td>
                <td>30</td>
            </tr>
            <tr>
                <td>Diploma in Food Technology</td>
                <td>2023-2024</td>
                <td>30</td>
            </tr>
            <tr>
                <td>Diploma in Information Technology</td>
                <td>2024-2025</td>
                <td>30</td>
            </tr>
            <tr>
                <td>Diploma in Mechanical Engineering (Industry Integrated)</td>
                <td>2025-2026</td>
                <td>30</td>
            </tr>
            <tr>
                <td>Diploma in Renewable Energy</td>
                <td>2024-2025</td>
                <td>30</td>
            </tr>
        
        </table>
    </div>
    <footer class="dept_footer">
    <p>© 2025 A.D. Patel Institute of Technology. All rights reserved.</p>
</footer>

<script src="/script.js"></script>
<script>
    document.getElementById('mobile-menu').addEventListener('click', function() {
        document.querySelector('.nav-links').classList.toggle('active');
    });
</script>
</body>
</html>