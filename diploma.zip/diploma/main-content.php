<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Principal's Message</title>
    <style>
        .container {
            width: 250px;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
            font-family: Arial, sans-serif;
        }
        .image {
            width: 100%;
            height: auto;
            border-bottom: 1px solid black;
            padding-bottom: 5px;
         
        }
        .text {
            font-size: 14px;
            margin: 5px 0;
            color:black;
        }
        .read-more {
            color:#2284c6 ;
            text-decoration: none;
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        .button {
            background-color: #2284c6;;
            color: black;
            padding: 8px;
            text-decoration: none;
            font-weight: bold;
            display: block;
        }
    </style>
</head>
<body>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Breaking News Ticker</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
        }
        .ticker-container {
            background: red;
            color: white;
            padding: 10px;
            overflow: hidden;
            position: relative;
            width: 100%;
            white-space: nowrap;
        }
        .ticker {
            display: inline-block;
            white-space: nowrap;
            animation: tickerMove 45s linear infinite;
        }
        .ticker a {
            color: yellow;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
        }
        @keyframes tickerMove {
            from { transform: translateX(100%); }
            to { transform: translateX(-100%); }
        }
    </style>
</head>
<body>
    <div class="ticker-container">
        <div class="ticker" id="newsTicker">
            <!-- News headlines will be inserted dynamically here -->
        </div>
    </div>
    
    <script>
        const newsData = [
            { text: "CVM UNIVERSITY", link: "https://youtu.be/UcDnm5pqDxw?si=MYk65cJtauI1ciSe" },
            { text: "ADIT", link: "https://youtu.be/UcDnm5pqDxw?si=zepGjokz7yvRDZH5" },
            { text: "Video Gallery ", link: "link.php" },
    
        ];
        
        function updateTicker() {
            const ticker = document.getElementById("newsTicker");
            ticker.innerHTML = newsData.map(news => `<a href="${news.link}" target="_blank">${news.text}</a>`).join(" | ");
        }
        
        updateTicker();
    </script>
</body>
</html>



<div class="main-container">
    <!-- Left Sidebar -->
    <aside class="sidebar">
        <ul class="sidebar-links">
            <li><a href="index.php?page=about-diploma" class="<?php echo $page === 'about-diploma' ? 'active' : ''; ?>" data-section="about-diploma">About Diploma</a></li>
            <li><a href="http://adit.ac.in/academicsection.html" target="_blank" class="<?php echo $page === 'academic-session' ? 'active' : ''; ?>" data-section="academic-session">Academic Section</a></li>
            <li><a href="http://adit.ac.in/admin_section.html" target="_blank" class="<?php echo $page === 'admin-session' ? 'active' : ''; ?>" data-section="admin-session">Admin Section</a></li>
            <li><a href="https://www.gtu.ac.in/AcademicCal.aspx" target="_blank" class="<?php echo $page === 'academic-calendar' ? 'active' : ''; ?>" data-section="academic-calendar">Academic Calendar</a></li>
            <li><a href="department.php" target="_blank" class="<?php echo $page === 'admin-session' ? 'active' : ''; ?>" data-section="admin-session">Department</a></li>
            <li><a href="http://adit.ac.in/payfeesonline.html" target="_blank" class="<?php echo $page === 'pay-fees-online' ? 'active' : ''; ?>" data-section="pay-fees-online">Pay-Fees-Online</a></li>
            <li><a href="http://adit.ac.in/inpress.html" target="_blank" class="<?php echo $page === 'admin-session' ? 'active' : ''; ?>" data-section="admin-session">Press Articles</a></li>
            <li><a href="http://adit.ac.in/committees.html" target="_blank" class="<?php echo $page === 'academic-calendar' ? 'active' : ''; ?>" data-section="academic-calendar">Various Committees</a></li>

        </ul>

        <!-- Chairman's Message Section -->
        <div class="container">
            <img src="images/chairman.jpg" alt="Chairman's Image" class="image">
            <p class="text">Education is the foundation of progress and innovation.</p>
            <a href="http://adit.ac.in/chairmansmessage.html" target="_blank" class="read-more">Read More...</a>
            <a href="#" target="_blank" class="button">Chairman's Message</a>
        </div>
        <!-- Principal's Message Section
        <div class="container">
            <img src="images/principal.jpg" alt="Principal's Image" class="image">
            <p class="text">Education is said to be the transmission of knowledge, culture and civilization.</p>
            <a href="http://adit.ac.in/principalsmessage.html" target="_blank" class="read-more">Read More...</a>
            <a href="#" target="_blank" class="button">Principal's Message</a>
        </div> -->
    </aside>

    <!-- Middle Content Area -->
     
    <section class="content-area">
        <?php
        $content_files = [
            'about-diploma' => 'content/about-diploma.php',
            'academic-session' => 'content/academic-session.php',
            'admin-session' => 'content/admin-session.php',
            'academic-calendar' => 'content/academic-calendar.php'
        ];
        
        $file = isset($content_files[$page]) ? $content_files[$page] : $content_files['about-diploma'];
        include $file;
        ?>
    </section>

    <!-- Right Notices/Links Section -->
    <?php include 'notices.php'; ?>
</div>

</body>
</html>
