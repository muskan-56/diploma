<?php
// No redirect; just set a default section
$section = isset($_GET['section']) ? $_GET['section'] : 'vision';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diploma Programs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="dept.css">
    <style>
           body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
            text-align: center;
        }
        .table-container {
            margin: 20px auto;
            width: 90%;
            max-width: 600px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 12px;
            text-align: center;
        }
        th {
            background: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background: #f2f2f2;
        }
        .back-link {
            margin-top: 20px;
        }
        .back-link a {
            text-decoration: none;
            color: white;
            background: #007BFF;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <?php include 'navbar.php'; ?>
    <div class="table-container">
        <h2>Fee Structure</h2>
        <table>
            <tr>
                <th>Year</th>
                <th>Fees (INR per year)</th>
            </tr>
            <tr>
                <td>2023-24</td>
                <td>49,000</td>
            </tr>
            <tr>
                <td>2024-25</td>
                <td>49,000</td>
            </tr>
            <tr>
                <td>2025-26</td>
                <td>51,000</td>
            </tr>
        </table>
    </div>
    <!-- <div class="back-link">
        <a href="department.php" target="_blank">Back to Diploma Programs</a>
    </div> -->
    <footer class="dept_footer">
    <p>© 2025 A.D. Patel Institute of Technology. All rights reserved.</p>
</footer>

<script src="/script.js"></script>
<script>
    document.getElementById('mobile-menu').addEventListener('click', function() {
        document.querySelector('.nav-links').classList.toggle('active');
    });
</script>
</body>
</html>