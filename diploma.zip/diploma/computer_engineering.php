<?php
// No redirect; just set a default section
$section = isset($_GET['section']) ? $_GET['section'] : 'vision';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diploma in Computer Engineering - ADIT</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="dept.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <?php include 'navbar.php'; ?>

    <!-- Consistent Top Banner Image -->
    <!-- <div class="dept_top-banner">
        <img src="/images/adit_dept_banner.jpg" alt="Department Banner" class="dept_banner-image">
    </div> -->

    <!-- Main Container with Sidebar and Content -->
    <div class="dept_main-container">
        <!-- Left Sidebar -->
        <aside class="dept_sidebar">
            <h2>Sections</h2>
            <ul class="dept_sidebar-menu">
                <li><a href="computer_engineering.php?section=vision" class="<?php echo ($section === 'vision') ? 'active' : ''; ?>">Vision & Mission</a></li>
                <li><a href="computer_engineering.php?section=program" class="<?php echo ($section === 'program') ? 'active' : ''; ?>">Program Details</a></li>
                <li><a href="http://adit.ac.in/cpfaculties.html" target="_blank" class="<?php echo ($section === 'faculty') ? 'active' : ''; ?>">Faculty</a></li>
                <li><a href="http://adit.ac.in/cpsupportstaff.html" target="_blank" class="<?php echo ($section === 'staff') ? 'active' : ''; ?>">Staff</a></li>
                <li><a href="http://adit.ac.in/cplab.html" target="_blank" class="<?php echo ($section === 'labs') ? 'active' : ''; ?>">Laboratories</a></li>
                <!-- <li><a href="computer_engineering.php?section=curriculum" class="<?php echo ($section === 'curriculum') ? 'active' : ''; ?>">Curriculum</a></li>
                <li><a href="computer_engineering.php?section=contact" class="<?php echo ($section === 'contact') ? 'active' : ''; ?>">Contact</a></li>
            -->
            </ul>
        </aside>

        <!-- Right Content Area -->
        <main class="dept_content">
            <h1>Diploma in Computer Engineering</h1>
            <?php
            switch ($section) {
                case 'vision':
                    echo '
                    <section class="dept_vision-mission">
                        <h2>Vision</h2>
                        <p>To be a leading center of excellence in computer engineering education, fostering innovation, and producing skilled professionals who contribute to technological advancements globally.</p>
                        <h2>Mission</h2>
                        <ul>
                            <li>To provide quality education in computer engineering through a robust curriculum.</li>
                            <li>To promote research and innovation in emerging technologies.</li>
                            <li>To develop ethical and socially responsible engineers.</li>
                        </ul>
                    </section>';
                    break;

                case 'program':
                    echo '
                    <section class="dept_program-details">
                        <h2>Program Details</h2>
                        <ul>
                            <li><strong>Duration:</strong> 3 years</li>
                            <li><strong>Intake:</strong> 30 students per year</li>
                            <li><strong>Eligibility:</strong> 10th standard (SSC) pass with Mathematics, Science, and English (as per Gujarat state norms)</li>
                            <li><strong>Mode:</strong> Full-time</li>
                        </ul>
                    </section>';
                    break;

                case 'faculty':
                    echo '
                    <section class="dept_faculty">
                        <h2>Faculty</h2>
                        <div class="dept_faculty-list">
                            <div class="dept_faculty-member">
                                <h3>Prof. John Doe</h3>
                                <p><strong>Designation:</strong> Head of Department</p>
                                <p><strong>Qualification:</strong> M.Tech (Computer Engineering)</p>
                                <p><strong>Experience:</strong> 15 years</p>
                            </div>
                            <div class="dept_faculty-member">
                                <h3>Dr. Jane Smith</h3>
                                <p><strong>Designation:</strong> Associate Professor</p>
                                <p><strong>Qualification:</strong> Ph.D. (Computer Science)</p>
                                <p><strong>Experience:</strong> 10 years</p>
                            </div>
                            <div class="dept_faculty-member">
                                <h3>Mr. Raj Patel</h3>
                                <p><strong>Designation:</strong> Assistant Professor</p>
                                <p><strong>Qualification:</strong> M.E. (Software Engineering)</p>
                                <p><strong>Experience:</strong> 7 years</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'staff':
                    echo '
                    <section class="dept_staff">
                        <h2>Technical Staff</h2>
                        <div class="dept_staff-list">
                            <div class="dept_staff-member">
                                <h3>Mr. Amit Sharma</h3>
                                <p><strong>Role:</strong> Lab Assistant</p>
                                <p><strong>Qualification:</strong> Diploma in Computer Engineering</p>
                                <p><strong>Experience:</strong> 5 years</p>
                            </div>
                            <div class="dept_staff-member">
                                <h3>Ms. Priya Desai</h3>
                                <p><strong>Role:</strong> System Administrator</p>
                                <p><strong>Qualification:</strong> B.Sc. (IT)</p>
                                <p><strong>Experience:</strong> 4 years</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'labs':
                    echo '
                    <section class="dept_labs">
                        <h2>Laboratories</h2>
                        <div class="dept_lab-list">
                            <div class="dept_lab">
                                <h3>Programming Lab</h3>
                                <p>Equipped with 30 high-performance PCs, licensed software (e.g., Visual Studio, Eclipse), and high-speed internet for coding practice.</p>
                            </div>
                            <div class="dept_lab">
                                <h3>Networking Lab</h3>
                                <p>Features Cisco routers, switches, and simulation tools like Packet Tracer for hands-on network configuration.</p>
                            </div>
                            <div class="dept_lab">
                                <h3>Hardware Lab</h3>
                                <p>Includes microprocessors, microcontrollers, and troubleshooting kits for practical hardware learning.</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'curriculum':
                    echo '
                    <section class="dept_curriculum">
                        <h2>Curriculum Highlights</h2>
                        <p>The curriculum includes a mix of core subjects, electives, and hands-on projects:</p>
                        <ul>
                            <li>Programming Fundamentals (C, C++, Java)</li>
                            <li>Database Management Systems</li>
                            <li>Computer Networks</li>
                            <li>Operating Systems</li>
                            <li>Microprocessors and Microcontrollers</li>
                            <li>Web Development</li>
                            <li>Project Work (Final Year)</li>
                        </ul>
                    </section>';
                    break;

               

                // case 'contact':
                //     echo '
                //     <section class="dept_contact">
                //         <h2>Contact</h2>
                //         <p>For inquiries, reach out to the Computer Engineering Department at <a href="mailto:computer@adit.ac.in">computer@adit.ac.in</a>.</p>
                //     </section>';
                //     break;

                default:
                    echo '<p>Section not found. Please select an option from the sidebar.</p>';
                    break;
            }
            ?>
        </main>
    </div>

    <footer class="dept_footer">
        <p>© 2025 A.D. Patel Institute of Technology. All rights reserved.</p>
    </footer>

    <script src="/script.js"></script>
    <script>
        document.getElementById('mobile-menu').addEventListener('click', function() {
            document.querySelector('.nav-links').classList.toggle('active');
        });
    </script>
</body>
</html>