<?php
// No redirect; just set a default section
$section = isset($_GET['section']) ? $_GET['section'] : 'vision';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diploma in Automobile Engineering - ADIT</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="dept.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <?php include 'navbar.php'; ?>

    <!-- Consistent Top Banner Image -->
    <!-- <div class="dept_top-banner">
        <img src="/images/adit_dept_banner.jpg" alt="Department Banner" class="dept_banner-image">
    </div> -->

    <!-- Main Container with Sidebar and Content -->
    <div class="dept_main-container">
        <!-- Left Sidebar -->
        <aside class="dept_sidebar">
            <h2>Sections</h2>
            <ul class="dept_sidebar-menu">
                <li><a href="automobile.php?section=vision" class="<?php echo ($section === 'vision') ? 'active' : ''; ?>">Vision & Mission</a></li>
                <li><a href="automobile.php?section=program" class="<?php echo ($section === 'program') ? 'active' : ''; ?>">Program Details</a></li>
                <li><a href="http://adit.ac.in/aefaculties.html" target="_blank" class="<?php echo ($section === 'faculty') ? 'active' : ''; ?>">Faculty</a></li>
                <li><a href="http://adit.ac.in/aesupportstaff.html" target="_blank" class="<?php echo ($section === 'staff') ? 'active' : ''; ?>">Staff</a></li>
                <li><a href="http://adit.ac.in/aelab.html" target="_blank" class="<?php echo ($section === 'labs') ? 'active' : ''; ?>">Laboratories</a></li>
                <!-- <li><a href="automobile.php?section=curriculum" class="<?php echo ($section === 'curriculum') ? 'active' : ''; ?>">Curriculum</a></li>
                <li><a href="automobile.php?section=contact" class="<?php echo ($section === 'contact') ? 'active' : ''; ?>">Contact</a></li>
           -->
            </ul>
        </aside>

        <!-- Right Content Area -->
        <main class="dept_content">
            <h1>Diploma in Automobile Engineering</h1>
            <?php
            switch ($section) {
                case 'vision':
                    echo '
                    <section class="dept_vision-mission">
                        <h2>Vision</h2>
                        <p>Instil enduring values and excellence in learning fundamental knowledge of automobile engineering, in universally relevant context for industry and society.
</p>
                        <h2>Mission</h2>
                        <ul>
                            <li>Creating conducive environment for learning practical applications of latest technology through state-of-the-art laboratory facilities</li>
                            <li>Providing opportunities for interaction with industry experts, visits to automotive industry and automotive research organizations</li>
                            <li>Motivate and support students for participating in National level competition events for out of classroom practical learning for hands-on practice and development of a professional with ability to work in team and problem solving
</li>
                        </ul>
                    </section>';
                    break;

                case 'program':
                    echo '
                    <section class="dept_program-details">
                        <h2>Program Details</h2>
                        <ul>
                            <li><strong>Duration:</strong> 3 years</li>
                            <li><strong>Intake:</strong> 30 students per year</li>
                            <li><strong>Eligibility:</strong> 10th standard (SSC) pass with Mathematics, Science, and English (as per Gujarat state norms)</li>
                            <li><strong>Mode:</strong> Full-time</li>
                        </ul>
                    </section>';
                    break;

                case 'faculty':
                    echo '
                    <section class="dept_faculty">
                        <h2>Faculty</h2>
                        <div class="dept_faculty-list">
                            <div class="dept_faculty-member">
                                <h3>Prof. Ramesh Patel</h3>
                                <p><strong>Designation:</strong> Head of Department</p>
                                <p><strong>Qualification:</strong> M.Tech (Automobile Engineering)</p>
                                <p><strong>Experience:</strong> 18 years</p>
                            </div>
                            <div class="dept_faculty-member">
                                <h3>Dr. Sanjay Kumar</h3>
                                <p><strong>Designation:</strong> Associate Professor</p>
                                <p><strong>Qualification:</strong> Ph.D. (Automotive Engineering)</p>
                                <p><strong>Experience:</strong> 12 years</p>
                            </div>
                            <div class="dept_faculty-member">
                                <h3>Mr. Vikram Shah</h3>
                                <p><strong>Designation:</strong> Assistant Professor</p>
                                <p><strong>Qualification:</strong> M.E. (Automobile Engineering)</p>
                                <p><strong>Experience:</strong> 6 years</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'staff':
                    echo '
                    <section class="dept_staff">
                        <h2>Technical Staff</h2>
                        <div class="dept_staff-list">
                            <div class="dept_staff-member">
                                <h3>Mr. Anil Sharma</h3>
                                <p><strong>Role:</strong> Lab Assistant</p>
                                <p><strong>Qualification:</strong> Diploma in Automobile Engineering</p>
                                <p><strong>Experience:</strong> 7 years</p>
                            </div>
                            <div class="dept_staff-member">
                                <h3>Ms. Neha Desai</h3>
                                <p><strong>Role:</strong> Technical Assistant</p>
                                <p><strong>Qualification:</strong> B.Sc. (Physics)</p>
                                <p><strong>Experience:</strong> 4 years</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'labs':
                    echo '
                    <section class="dept_labs">
                        <h2>Laboratories</h2>
                        <div class="dept_lab-list">
                            <div class="dept_lab">
                                <h3>Automotive Workshop</h3>
                                <p>Equipped with engine testing setups, diagnostic tools, and vehicle assembly units for practical training.</p>
                            </div>
                            <div class="dept_lab">
                                <h3>Vehicle Dynamics Lab</h3>
                                <p>Includes suspension testing equipment and simulation tools for studying vehicle dynamics.</p>
                            </div>
                            <div class="dept_lab">
                                <h3>Automotive Electronics Lab</h3>
                                <p>Features ECUs, sensors, and diagnostic software for hands-on automotive electronics training.</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'curriculum':
                    echo '
                    <section class="dept_curriculum">
                        <h2>Curriculum Highlights</h2>
                        <p>The curriculum includes a mix of core subjects, electives, and hands-on projects:</p>
                        <ul>
                            <li>Automotive Engines</li>
                            <li>Vehicle Dynamics</li>
                            <li>Automotive Electronics</li>
                            <li>Automobile Chassis and Transmission</li>
                            <li>Hybrid and Electric Vehicles</li>
                            <li>Automotive Design</li>
                            <li>Project Work (Final Year)</li>
                        </ul>
                    </section>';
                    break;

               

                case 'contact':
                    echo '
                    <section class="dept_contact">
                        <h2>Contact</h2>
                        <p>For inquiries, reach out to the Automobile Engineering Department at <a href="mailto:automobile@adit.ac.in">automobile@adit.ac.in</a>.</p>
                    </section>';
                    break;

                default:
                    echo '<p>Section not found. Please select an option from the sidebar.</p>';
                    break;
            }
            ?>
        </main>
    </div>

    <footer class="dept_footer">
        <p>© 2025 A.D. Patel Institute of Technology. All rights reserved.</p>
    </footer>

    <script src="/script.js"></script>
    <script>
        document.getElementById('mobile-menu').addEventListener('click', function() {
            document.querySelector('.nav-links').classList.toggle('active');
        });
    </script>
</body>
</html>