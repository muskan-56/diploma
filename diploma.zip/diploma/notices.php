<!-- notices.php -->
<aside class="notices-section">
    <h2>Notices & Links</h2>
    <div class="notices-content">
        <h3>Latest Notices</h3>
        <ul>
            <li><a href="#">College Timings: Monday - Friday 09:00 AM to 05:00 PM, Saturday: 09:00 AM to 01:00 PM</a></li>
            <li><a href="#">2nd & 4th Saturday Holiday</a></li>
            <li><a href="#">Lunch Timing: 12:40 PM to 1:25 PM</a></li>
        </ul>
    <!-- Contact & Social Media Section -->
    <div class="contact-section">
        <h3>Connect with us</h3>
        <p>Follow us on social media and be the first to find out about our announcements and events!</p>
        <div class="social-icons">
        <a href="https://www.facebook.com/adit.cvmuniversity" target="_blank" >
        <img src="images/facebook.png" alt="Facebook">
    </a>
    <a href="https://twitter.com/adit_cvmu" target="_blank">
        <img src="images/twitter.png" alt="Twitter">
    </a>
    <a href="https://www.instagram.com/adit_cvmuniversity/" target="_blank" >
        <img src="images/instagram.jpeg" alt="Instagram">
    </a>
    <a href="https://www.linkedin.com/school/adit_cvmuniversity" target="_blank" >
        <img src="images/linkedin.png" alt="LinkedIn">
    </a>
        </div>
    
        <h3>Subscribe to our Newsletter</h3>
        <form action="#" method="post">
            <input type="email" name="email" placeholder="Email address" required>
            <button type="submit">Subscribe</button>
        </form>
    </div>

         <!-- Principal's Message Section -->
         <div class="container">
            <img src="images/principal.jpg" alt="Principal's Image" class="image">
            <p class="text">Education is said to be the transmission of knowledge, culture and civilization.</p>
            <a href="http://adit.ac.in/principalsmessage.html" target="_blank" class="read-more">Read More...</a>
            <a href="#" target="_blank" class="button">Principal's Message</a>
        </div>
    </aside>
<!-- Linking CSS -->
<link rel="stylesheet" href="styles.css">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Principal's Message</title>
    <style>
        .container {
            width: 250px;
            color:black;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
            font-family: Arial, sans-serif;
        }
        .image {
            width: 100%;
            height: auto;
            border-bottom: 1px solid black;
            padding-bottom: 5px;
        }
        .text {
            font-size: 14px;
            color:black;
            margin: 5px 0;
        }
        .read-more {
            color:black ;
            text-decoration: none;
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        .button {
            background-color:yellow;
            color: black;
            /* padding: 8px;
            text-decoration: none;
            font-weight: bold;
            display: block; */
        }
    </style>
</head>
<body>