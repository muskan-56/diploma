<!-- footer.php -->
<footer id="contact-footer" class="footer">
    <div class="footer-container">
        <h3>Contact Us</h3>
        <p><strong>Address:</strong> A D Patel Institute of Technology, New Vallabh Vidyanagar, Vitthal Udyognagar, Anand, Gujarat 388121, India</p>
        <p><strong>Phone:</strong> +91-2692-233680</p>
        <p><strong>Email:</strong> <a href="mailto:info@adit.ac.in">info@adit.ac.in</a></p>
        <p><strong>Website:</strong> <a href="http://www.adit.ac.in" target="_blank">www.adit.ac.in</a></p>

        <!-- Updated Social Links (merged both changes) -->
        <div class="social-links">
            <a href="https://www.facebook.com/adit.cvmuniversity" target="_blank">Facebook</a> | 
            <a href="https://www.instagram.com/adit_cvmuniversity/" target="_blank">Instagram</a> | 
            <a href="https://twitter.com/adit_cvmu" target="_blank">Twitter</a> | 
            <a href="https://www.linkedin.com/school/adit_cvmuniversity" target="_blank">LinkedIn</a>
        </div>

        <p class="copyright">© <?php echo date('Y'); ?> A D Patel Institute of Technology. All rights reserved.</p>
    </div>
</footer>
