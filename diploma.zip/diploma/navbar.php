<!-- navbar.php -->
<nav class="navbar">
    <div class="nav-container">
        <ul class="nav-links">
            <li><a href="index.php?page=about-diploma">Home</a></li>
            
            <li class="dropdown">
                <a href="#">About Us ▼</a>
                <ul class="dropdown-menu">
                    <li><a href="http://adit.ac.in/" target="_blank">About ADIT</a></li>
                    <li><a href="http://cvm.edu.in/" target="_blank">About CVM University</a></li>
                    <li><a href="http://www.ecvm.net/" target="_blank">About Management</a></li>
                    <li><a href="http://adit.ac.in/chairmansmessage.html" target="_blank">Chairman's Message</a></li>
                    <li><a href="http://adit.ac.in/principalsmessage.html" target="_blank">Principal's Message</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#">Programs ▼</a>   
                <ul class="dropdown-menu">
                    <li><a href="automobile.php">Diploma in Automobile Engineering</a></li>
                    <li><a href="computer_engineering.php">Diploma in Computer Engineering</a></li>
                    <li><a href="electrical.php">Diploma in Electrical Engineering (Industrial Control)</a></li>
                    <li><a href="electronics.php">Diploma in Electronics Engineeing(Specialization Consumer Electronics)</a></li>
                    <li><a href="food_processing.php">Diploma in Food Technology</a></li>
                    <li><a href="it.php">Diploma in Information Technology</a></li>
                    <li><a href="mechanical.php">Diploma in Mechanical Engineering (Industry Integrated)</a></li>
                    <li><a href="renewable.php">Diploma in Renewable Energy</a></li>   
                </ul>
            </li>

            <li class="dropdown">
                <a href="#">Admission ▼</a>
                <ul class="dropdown-menu">
                    <li><a href="http://google.co.in/maps/place/A.+D.+Patel+Institute+of+Technology,+New+Vallabh+Vidyanagar/" target="_blank">ADIT 360</a></li> 
                    <li><a href="http://adit.ac.in/admission.html" target="_blank">Admission Inquiry</a></li>
                    <li><a href="C:\xampp\htdocs\diploma\brochure.pdf" target="_blank">Brochure</a></li>
                    <li><a href="Fees_Structure.php" target="_blank">Fees Structure</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#">Facilities ▼</a>
                <ul class="dropdown-menu">
                    <li><a href="http://adit.ac.in/idealab.html" target="_blank">Idea Lab</a></li>
                    <li><a href="http://adit.ac.in/library.html" target="_blank">Library</a></li>
                    <li><a href="http://adit.ac.in/sportsdept.html" target="_blank">Sports</a></li>
                    <li><a href="http://adit.ac.in/auditorium.html" target="_blank">Auditorium</a></li>
                    <li><a href="http://adit.ac.in/ncc.html" target="_blank">NCC</a></li>
                    <li><a href="http://adit.ac.in/nss.html" target="_blank">NSS</a></li>
                    <li><a href="http://adit.ac.in/ssip.html" target="_blank">SSIP Cell</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#">Student Corner ▼</a>
                <ul class="dropdown-menu">
                    <li><a href="http://adit.ac.in/scholarship.html" target="_blank">Scholarship</a></li>
                    <li><a href="http://adit.ac.in/houses.html" target="_blank">Houses</a></li>
                    <li><a href="http://adit.ac.in/clubs.html" target="_blank">Clubs</a></li>
                    <li><a href="http://adit.ac.in/webinars.html" target="_blank">Event</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#">Campus ▼</a>
                <ul class="dropdown-menu">
                    <li><a href="http://adit.ac.in/hostel_boys.html" target="_blank">ADIT Boys Hostel</a></li>
                    <li><a href="http://adit.ac.in/hostel_girls.html" target="_blank">ADIT Girls Hostel</a></li>
                    <li><a href="http://adit.ac.in/gallery4.html" target="_blank">Photo Gallery</a></li>
                </ul>
            </li>

            <li><a href="http://adit.ac.in/contact.html" target="_blank">Contact Us</a></li>
        </ul>
        <div class="menu-toggle" id="mobile-menu">☰</div>
    </div>
</nav>
