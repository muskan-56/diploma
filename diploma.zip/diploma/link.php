<?php
// No redirect; just set a default section
$section = isset($_GET['section']) ? $_GET['section'] : 'vision';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diploma Programs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="dept.css">
    <style>
     body {
            
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
            text-align: center;
        }
    
        .links-container {
            margin: 20px auto;
            width: 90%;
            max-width: 800px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            color:blue;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            margin: 10px 0;
        }
        a {
            display: inline-block;

            color:blue;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
    </style>
</head>
<body>
<?php include 'header.php'; ?>
<?php include 'navbar.php'; ?>
    <div class="links-container">
        <h2>Useful Links</h2>
        <ul>
            <li><a href="https://youtu.be/UcDnm5pqDxw?si=MYk65cJtauI1ciSe" target="_blank">About CVM University</a></li>
            <li><a href="https://youtu.be/UcDnm5pqDxw?si=zepGjokz7yvRDZH5" target="_blank">About ADIT</a></li>
        </ul>
    </div>
    <footer class="dept_footer">
    <p>© 2025 A.D. Patel Institute of Technology. All rights reserved.</p>
</footer>

<script src="/script.js"></script>
<script>
    document.getElementById('mobile-menu').addEventListener('click', function() {
        document.querySelector('.nav-links').classList.toggle('active');
    });
</script>
</body>
</html>