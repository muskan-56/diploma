<!-- header.php -->
<header>
    <div class="header-container">
        <img id="header-image" src="assets/header_title.jpg?ver=<?php echo time(); ?>" alt="A D Patel Institute of Technology Header">
    </div>
</header>
