<?php
// No redirect; just set a default section
$section = isset($_GET['section']) ? $_GET['section'] : 'vision';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diploma in Food Processing Technology - ADIT</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="dept.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <?php include 'navbar.php'; ?>

    <!-- Consistent Top Banner Image -->
    <!-- <div class="dept_top-banner">
        <img src="/images/adit_dept_banner.jpg" alt="Department Banner" class="dept_banner-image">
    </div> -->

    <!-- Main Container with Sidebar and Content -->
    <div class="dept_main-container">
        <!-- Left Sidebar -->
        <aside class="dept_sidebar">
            <h2>Sections</h2>
            <ul class="dept_sidebar-menu">
                <li><a href="food_processing.php?section=vision" class="<?php echo ($section === 'vision') ? 'active' : ''; ?>">Vision & Mission</a></li>
                <li><a href="food_processing.php?section=program" class="<?php echo ($section === 'program') ? 'active' : ''; ?>">Program Details</a></li>
                <li><a href="http://adit.ac.in/fptfaculties.html" target="_blank" class="<?php echo ($section === 'faculty') ? 'active' : ''; ?>">Faculty</a></li>
                <li><a href="http://adit.ac.in/fptsupportstaff.html" target="_blank" class="<?php echo ($section === 'staff') ? 'active' : ''; ?>">Staff</a></li>
                <li><a href="http://adit.ac.in/fptlab.html" target="_blank" class="<?php echo ($section === 'labs') ? 'active' : ''; ?>">Laboratories</a></li>
                <!-- <li><a href="food_processing.php?section=curriculum" class="<?php echo ($section === 'curriculum') ? 'active' : ''; ?>">Curriculum</a></li>
                <li><a href="food_processing.php?section=contact" class="<?php echo ($section === 'contact') ? 'active' : ''; ?>">Contact</a></li>
             -->
            </ul>
        </aside>

        <!-- Right Content Area -->
        <main class="dept_content">
            <h1>Diploma in Food Processing Technology</h1>
            <?php
            switch ($section) {
                case 'vision':
                    echo '
                    <section class="dept_vision-mission">
                        <h2>Vision</h2>
                        <p>To be a leading center for food processing technology education, fostering innovation and producing skilled professionals for the food industry.</p>
                        <h2>Mission</h2>
                        <ul>
                            <li>To provide quality education in food processing technology with a focus on practical skills.</li>
                            <li>To promote research in food safety and preservation techniques.</li>
                            <li>To develop ethical and socially responsible professionals for the food industry.</li>
                        </ul>
                    </section>';
                    break;

                case 'program':
                    echo '
                    <section class="dept_program-details">
                        <h2>Program Details</h2>
                        <ul>
                            <li><strong>Duration:</strong> 3 years</li>
                            <li><strong>Intake:</strong> 30 students per year</li>
                            <li><strong>Eligibility:</strong> 10th standard (SSC) pass with Mathematics, Science, and English (as per Gujarat state norms)</li>
                            <li><strong>Mode:</strong> Full-time</li>
                        </ul>
                    </section>';
                    break;

                case 'faculty':
                    echo '
                    <section class="dept_faculty">
                        <h2>Faculty</h2>
                        <div class="dept_faculty-list">
                            <div class="dept_faculty-member">
                                <h3>Prof. Neha Sharma</h3>
                                <p><strong>Designation:</strong> Head of Department</p>
                                <p><strong>Qualification:</strong> M.Tech (Food Technology)</p>
                                <p><strong>Experience:</strong> 15 years</p>
                            </div>
                            <div class="dept_faculty-member">
                                <h3>Dr. Rajesh Kumar</h3>
                                <p><strong>Designation:</strong> Associate Professor</p>
                                <p><strong>Qualification:</strong> Ph.D. (Food Science)</p>
                                <p><strong>Experience:</strong> 10 years</p>
                            </div>
                            <div class="dept_faculty-member">
                                <h3>Ms. Priya Patel</h3>
                                <p><strong>Designation:</strong> Assistant Professor</p>
                                <p><strong>Qualification:</strong> M.Sc. (Food Technology)</p>
                                <p><strong>Experience:</strong> 5 years</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'staff':
                    echo '
                    <section class="dept_staff">
                        <h2>Technical Staff</h2>
                        <div class="dept_staff-list">
                            <div class="dept_staff-member">
                                <h3>Mr. Anil Desai</h3>
                                <p><strong>Role:</strong> Lab Assistant</p>
                                <p><strong>Qualification:</strong> Diploma in Food Processing</p>
                                <p><strong>Experience:</strong> 6 years</p>
                            </div>
                            <div class="dept_staff-member">
                                <h3>Ms. Shalini Gupta</h3>
                                <p><strong>Role:</strong> Technical Assistant</p>
                                <p><strong>Qualification:</strong> B.Sc. (Food Science)</p>
                                <p><strong>Experience:</strong> 3 years</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'labs':
                    echo '
                    <section class="dept_labs">
                        <h2>Laboratories</h2>
                        <div class="dept_lab-list">
                            <div class="dept_lab">
                                <h3>Food Processing Lab</h3>
                                <p>Equipped with food processing equipment like pasteurizers, dehydrators, and packaging machines.</p>
                            </div>
                            <div class="dept_lab">
                                <h3>Quality Control Lab</h3>
                                <p>Includes instruments for testing food safety, such as pH meters and microbial testing kits.</p>
                            </div>
                            <div class="dept_lab">
                                <h3>Food Preservation Lab</h3>
                                <p>Features canning units, freeze-drying equipment, and cold storage for preservation experiments.</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'curriculum':
                    echo '
                    <section class="dept_curriculum">
                        <h2>Curriculum Highlights</h2>
                        <p>The curriculum includes a mix of core subjects, electives, and hands-on projects:</p>
                        <ul>
                            <li>Food Chemistry</li>
                            <li>Food Microbiology</li>
                            <li>Food Processing Techniques</li>
                            <li>Food Preservation</li>
                            <li>Quality Control in Food Industry</li>
                            <li>Packaging Technology</li>
                            <li>Project Work (Final Year)</li>
                        </ul>
                    </section>';
                    break;

               

                // case 'contact':
                //     echo '
                //     <section class="dept_contact">
                //         <h2>Contact</h2>
                //         <p>For inquiries, reach out to the Food Processing Technology Department at <a href="mailto:foodprocessing@adit.ac.in">foodprocessing@adit.ac.in</a>.</p>
                //     </section>';
                //     break;

                default:
                    echo '<p>Section not found. Please select an option from the sidebar.</p>';
                    break;
            }
            ?>
        </main>
    </div>

    <footer class="dept_footer">
        <p>© 2025 A.D. Patel Institute of Technology. All rights reserved.</p>
    </footer>

    <script src="/script.js"></script>
    <script>
        document.getElementById('mobile-menu').addEventListener('click', function() {
            document.querySelector('.nav-links').classList.toggle('active');
        });
    </script>
</body>
</html>