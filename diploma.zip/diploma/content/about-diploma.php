<div id="about-diploma" class="content active">
    <h2>About Diploma</h2>
    <p>The Diploma program at A D Patel Institute of Technology (ADIT) is designed to provide students with a strong foundation in technical education, preparing them for both higher studies and industry roles. Below is an overview of our aims, mission, vision, and more.</p>
    <!-- Rest of the about diploma content -->
    <div class="slideshow-container">
    <img class="slides" src="images/s1.png" alt="Slide 1">
    <img class="slides" src="images/s5.jpeg" alt="Slide 2">
    <img class="slides" src="images/s2.jpg" alt="Slide 3">
    <img class="slides" src="images/s6.jpeg" alt="Slide 4">
    <img class="slides" src="images/s3.jpg" alt="Slide 5">
   
    
    
    <button class="prev" onclick="changeSlide(-1)">&#10094;</button>
    <button class="next" onclick="changeSlide(1)">&#10095;</button>
</div>

<script>
 let slideIndex = 0;
const slides = document.querySelectorAll(".slides");

function showSlides(index) {
    if (index >= slides.length) slideIndex = 0;
    if (index < 0) slideIndex = slides.length - 1;
    
    slides.forEach(slide => slide.style.display = "none");
    slides[slideIndex].style.display = "block";
}

function changeSlide(direction) {
    slideIndex += direction;
    showSlides(slideIndex);
}

// Initialize Slideshow
showSlides(slideIndex);


</script>
