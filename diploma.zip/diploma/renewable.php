<?php
// No redirect; just set a default section
$section = isset($_GET['section']) ? $_GET['section'] : 'vision';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diploma in Renewable Energy - ADIT</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="dept.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <?php include 'navbar.php'; ?>

    <!-- Consistent Top Banner Image -->
    <!-- <div class="dept_top-banner">
        <img src="/images/adit_dept_banner.jpg" alt="Department Banner" class="dept_banner-image">
    </div> -->

    <!-- Main Container with Sidebar and Content -->
    <div class="dept_main-container">
        <!-- Left Sidebar -->
        <aside class="dept_sidebar">
            <h2>Sections</h2>
            <ul class="dept_sidebar-menu">
                <li><a href="renewable.php?section=vision" class="<?php echo ($section === 'vision') ? 'active' : ''; ?>">Vision & Mission</a></li>
                <li><a href="renewable.php?section=program" class="<?php echo ($section === 'program') ? 'active' : ''; ?>">Program Details</a></li>
                <li><a href="http://adit.ac.in/mefaculties.html" target="_blank" class="<?php echo ($section === 'faculty') ? 'active' : ''; ?>">Faculty</a></li>
                <li><a href="http://adit.ac.in/mesupportstaff.html" target="_blank" class="<?php echo ($section === 'staff') ? 'active' : ''; ?>">Staff</a></li>
                <li><a href="http://adit.ac.in/melab.html" target="_blank" class="<?php echo ($section === 'labs') ? 'active' : ''; ?>">Laboratories</a></li>
                <!-- <li><a href="renewable.php?section=curriculum" class="<?php echo ($section === 'curriculum') ? 'active' : ''; ?>">Curriculum</a></li>
                <li><a href="renewable.php?section=contact" class="<?php echo ($section === 'contact') ? 'active' : ''; ?>">Contact</a></li>
          -->
            </ul>
        </aside>

        <!-- Right Content Area -->
        <main class="dept_content">
            <h1>Diploma in Renewable Energy</h1>
            <?php
            switch ($section) {
                case 'vision':
                    echo '
                    <section class="dept_vision-mission">
                        <h2>Vision</h2>
                        <p>To be a premier center for renewable energy education, fostering innovation and producing skilled professionals for sustainable energy solutions.</p>
                        <h2>Mission</h2>
                        <ul>
                            <li>To provide quality education in renewable energy with a focus on practical skills.</li>
                            <li>To promote research in solar, wind, and other renewable energy technologies.</li>
                            <li>To develop ethical and socially responsible professionals for the renewable energy sector.</li>
                        </ul>
                    </section>';
                    break;

                case 'program':
                    echo '
                    <section class="dept_program-details">
                        <h2>Program Details</h2>
                        <ul>
                            <li><strong>Duration:</strong> 3 years</li>
                            <li><strong>Intake:</strong> 30 students per year</li>
                            <li><strong>Eligibility:</strong> 10th standard (SSC) pass with Mathematics, Science, and English (as per Gujarat state norms)</li>
                            <li><strong>Mode:</strong> Full-time</li>
                        </ul>
                    </section>';
                    break;

                case 'faculty':
                    echo '
                    <section class="dept_faculty">
                        <h2>Faculty</h2>
                        <div class="dept_faculty-list">
                            <div class="dept_faculty-member">
                                <h3>Prof. Arjun Patel</h3>
                                <p><strong>Designation:</strong> Head of Department</p>
                                <p><strong>Qualification:</strong> M.Tech (Renewable Energy)</p>
                                <p><strong>Experience:</strong> 15 years</p>
                            </div>
                            <div class="dept_faculty-member">
                                <h3>Dr. Nisha Sharma</h3>
                                <p><strong>Designation:</strong> Associate Professor</p>
                                <p><strong>Qualification:</strong> Ph.D. (Solar Energy)</p>
                                <p><strong>Experience:</strong> 10 years</p>
                            </div>
                            <div class="dept_faculty-member">
                                <h3>Mr. Rohan Desai</h3>
                                <p><strong>Designation:</strong> Assistant Professor</p>
                                <p><strong>Qualification:</strong> M.E. (Renewable Energy)</p>
                                <p><strong>Experience:</strong> 5 years</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'staff':
                    echo '
                    <section class="dept_staff">
                        <h2>Technical Staff</h2>
                        <div class="dept_staff-list">
                            <div class="dept_staff-member">
                                <h3>Mr. Suresh Kumar</h3>
                                <p><strong>Role:</strong> Lab Assistant</p>
                                <p><strong>Qualification:</strong> Diploma in Renewable Energy</p>
                                <p><strong>Experience:</strong> 6 years</p>
                            </div>
                            <div class="dept_staff-member">
                                <h3>Ms. Anjali Patel</h3>
                                <p><strong>Role:</strong> Technical Assistant</p>
                                <p><strong>Qualification:</strong> B.Sc. (Environmental Science)</p>
                                <p><strong>Experience:</strong> 3 years</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'labs':
                    echo '
                    <section class="dept_labs">
                        <h2>Laboratories</h2>
                        <div class="dept_lab-list">
                            <div class="dept_lab">
                                <h3>Solar Energy Lab</h3>
                                <p>Equipped with solar panels, inverters, and testing equipment for solar energy experiments.</p>
                            </div>
                            <div class="dept_lab">
                                <h3>Wind Energy Lab</h3>
                                <p>Includes wind turbine models and simulation tools for studying wind energy systems.</p>
                            </div>
                            <div class="dept_lab">
                                <h3>Energy Storage Lab</h3>
                                <p>Features battery testing setups and energy storage systems for practical training.</p>
                            </div>
                        </div>
                    </section>';
                    break;

                case 'curriculum':
                    echo '
                    <section class="dept_curriculum">
                        <h2>Curriculum Highlights</h2>
                        <p>The curriculum includes a mix of core subjects, electives, and hands-on projects:</p>
                        <ul>
                            <li>Introduction to Renewable Energy</li>
                            <li>Solar Energy Systems</li>
                            <li>Wind Energy Systems</li>
                            <li>Energy Storage and Management</li>
                            <li>Bioenergy and Biomass</li>
                            <li>Energy Efficiency and Auditing</li>
                            <li>Project Work (Final Year)</li>
                        </ul>
                    </section>';
                    break;

              

                // case 'contact':
                //     echo '
                //     <section class="dept_contact">
                //         <h2>Contact</h2>
                //         <p>For inquiries, reach out to the Renewable Energy Department at <a href="mailto:renewable@adit.ac.in">renewable@adit.ac.in</a>.</p>
                //     </section>';
                //     break;

                default:
                    echo '<p>Section not found. Please select an option from the sidebar.</p>';
                    break;
            }
            ?>
        </main>
    </div>

    <footer class="dept_footer">
        <p>© 2025 A.D. Patel Institute of Technology. All rights reserved.</p>
    </footer>

    <script src="/script.js"></script>
    <script>
        document.getElementById('mobile-menu').addEventListener('click', function() {
            document.querySelector('.nav-links').classList.toggle('active');
        });
    </script>
</body>
</html>